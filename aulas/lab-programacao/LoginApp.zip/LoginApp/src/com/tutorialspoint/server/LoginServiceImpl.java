package com.tutorialspoint.server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.tutorialspoint.client.LoginService;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class LoginServiceImpl extends RemoteServiceServlet implements LoginService {

	@Override
	public Boolean login(String user, String password) throws IllegalArgumentException {
		try {
			
			Connection conn = DatabaseConnection.getDBConnection();
					
			String sql = "SELECT * FROM user_login "
				+ "WHERE login = '" + user + "' AND password = '" + password + "'";
			
			System.out.println("SQL: " + sql);
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			if (rs != null && rs.next()) {
				return new Boolean(true);
			} else {
				return new Boolean(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return new Boolean(false);		
	}
}
