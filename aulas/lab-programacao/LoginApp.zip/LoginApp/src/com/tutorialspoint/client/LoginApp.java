package com.tutorialspoint.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DecoratorPanel;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlexTable.FlexCellFormatter;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class LoginApp implements EntryPoint {
	/**
	 * The message displayed to the user when the server cannot be reached or
	 * returns an error.
	 */
	private static final String SERVER_ERROR = "An error occurred while "
			+ "attempting to contact the server. Please check your network " + "connection and try again.";

	/**
	 * Create a remote service proxy to talk to the server-side Greeting service.
	 */
	private final LoginServiceAsync loginService = GWT.create(LoginService.class);
		
	private FlexTable layout;

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		
		// The username field
		final TextBox userTextBox = new TextBox();
		userTextBox.getElement().setId("user_name");
		
		// The password field
		final TextBox passwordTextBox = new PasswordTextBox();
		passwordTextBox.getElement().setId("user_password");
		
		// The log in button
		Button submitButton = new Button("Submit");
		submitButton.getElement().setId("user_submit");
		
		// Create a handler for the sendButton and nameField
		class MyHandler implements ClickHandler, KeyUpHandler {
					/**
					 * Fired when the user clicks on the sendButton.
					 */
					public void onClick(ClickEvent event) {
						sendInfoLoginToServer();
					}

					/**
					 * Fired when the user types in the nameField.
					 */
					public void onKeyUp(KeyUpEvent event) {
						if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
							sendInfoLoginToServer();
						}
					}

					/**
					 * Send the name from the nameField to the server and wait for a response.
					 */
					private void sendInfoLoginToServer() {
						
						loginService.login(userTextBox.getText(), passwordTextBox.getText(), 
								new AsyncCallback<Boolean>() {

							@Override
							public void onFailure(Throwable caught) {
								// Perform Validations
								error("|=======<th>"
										+ "ErrorType</th><th>Error "
										+ "Description</th>|Fatal|"
										+ "Remote Procedure Call - Failure|=======");						
							}

							@Override
							public void onSuccess(Boolean result) {
								if (result != null && result.booleanValue()) {
									Window.alert("Bem vindo, " + userTextBox.getText() + "!");
								} else {
									Window.alert("Login ou Senha invalidos!!!");
								}
							}
						});
					}
				}

		// Add a handler to send the name to the server
		MyHandler handler = new MyHandler();
		submitButton.addClickHandler(handler);

		// Create a table to layout the form options
	    layout = new FlexTable();
	    layout.setCellSpacing(6);
	    FlexCellFormatter cellFormatter = layout.getFlexCellFormatter();

	    // Add a title to the form
	    layout.setHTML(0, 0, "LoginApp");
	    cellFormatter.setColSpan(0, 0, 2);
	    cellFormatter.setHorizontalAlignment(
	        0, 0, HasHorizontalAlignment.ALIGN_CENTER);

	    // Add some standard form options
	    layout.setHTML(1, 0, "Login:");
	    layout.setWidget(1, 1, userTextBox);
	    layout.setHTML(2, 0, "Senha:");
	    layout.setWidget(2, 1, passwordTextBox);
	    
	    layout.setWidget(3, 1, submitButton);

	    // Wrap the content in a DecoratorPanel
	    DecoratorPanel decPanel = new DecoratorPanel();
	    decPanel.setWidget(layout);
	    		
	    // Associate the Main panel with the HTML host page.
	    RootPanel.get("screen").add(decPanel);
	}
	
	/**
	* Custom Error Dialog Page.
	* @param err error message text
	*/
	public void error(String err) {
		final DialogBox dialog = new DialogBox();
		dialog.center();
		dialog.setSize("80%", "80%");
		dialog.setText("Error");
		
		VerticalPanel panel = new VerticalPanel();
		panel.setSize("100%", "100%");
		HTMLPanel html = new HTMLPanel(err);
		html.setSize("100%", "100%");
		panel.add(html);
		
		Button ok = new Button("OK");
		VerticalPanel buttonPanel = new VerticalPanel(); 
		buttonPanel.setSpacing(3);
		buttonPanel.add(ok);
		panel.add(buttonPanel);
		dialog.setWidget(panel);
		
		ok.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent arg0) {
				dialog.hide();
			}
		});
		
		dialog.show();
	}
}
