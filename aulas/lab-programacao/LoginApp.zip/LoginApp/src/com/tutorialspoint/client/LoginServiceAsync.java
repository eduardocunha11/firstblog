package com.tutorialspoint.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>LoginService</code>.
 */
public interface LoginServiceAsync {	
	
	void login(String user, String password, AsyncCallback<Boolean> callback) throws IllegalArgumentException;
	
}