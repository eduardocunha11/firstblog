package com.cefet.imc.server;

import com.cefet.imc.client.ImcService;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class ImcServiceImpl extends RemoteServiceServlet implements ImcService {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String calculaImc(String peso, String altura) throws IllegalArgumentException {
		
		/**
		 * IMC = peso em kg / (altura em metros * altura em metros)
		 */
		Double pesoPessoa = Double.valueOf(peso);
		Double alturaPessoa = Double.valueOf(altura) / 100;
		Double imc = pesoPessoa / (alturaPessoa * alturaPessoa);
		
		String resp = "";
		
		if (imc > 0) {
			if (imc < 15) {
				resp = imc + ":" + "Extremamente abaixo do peso";
			} else if (imc >= 15 && imc < 16) {
				resp = imc + ":" + "Gravemente abaixo do peso";
			} else if (imc >= 16 && imc < 18.5) {
				resp = imc + ":" + "Abaixo do peso ideal";
			} else if (imc >= 18.5 && imc < 25) {
				resp = imc + ":" + "Faixa de peso ideal";
			} else if (imc >= 25 && imc < 30) {
				resp = imc + ":" + "Sobrepeso";
			} else if (imc >= 30 && imc < 35) {
				resp = imc + ":" + "Obesidade grau I";
			} else if (imc >= 35 && imc < 40) {
				resp = imc + ":" + "Obesidade grau II (grave)";
			} else {
				resp = imc + ":" + "Obesidade grau II (grave)";
			}
		} else {
			resp = "-1:Imc Invalido!";
		}
		
		return resp;
	}
}
