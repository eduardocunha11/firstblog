package com.cefet.imc.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>ImcService</code>.
 */
public interface ImcServiceAsync {
	
	void calculaImc(String peso, String altura, AsyncCallback<String> callback) throws IllegalArgumentException;

}
