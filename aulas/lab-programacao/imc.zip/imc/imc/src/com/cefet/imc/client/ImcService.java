package com.cefet.imc.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * The client-side stub for the RPC service.
 */
@RemoteServiceRelativePath("service")
public interface ImcService extends RemoteService {
	
	String calculaImc(String peso, String altura) throws IllegalArgumentException;
}
