package com.tutorialspoint.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlexTable.FlexCellFormatter;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.tutorialspoint.shared.SaleInfo;
import com.tutorialspoint.shared.SerialList;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class CarSales implements EntryPoint {
	/**
	 * The message displayed to the user when the server cannot be reached or
	 * returns an error.
	 */
	private static final String SERVER_ERROR = "An error occurred while "
			+ "attempting to contact the server. Please check your network " + "connection and try again.";

	/**
	 * Create a remote service proxy to talk to the server-side Greeting service.
	 */
	private final CarServiceAsync carService = GWT.create(CarService.class);
	
	private FlexTable resultsTable;
	
	private FlexCellFormatter cellFormatter;

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		
		final Label clientNameLb = new Label("Nome: ");
		clientNameLb.getElement().setId("clientNameLb");
		
		// The client name field
		final TextBox clientTxtBox = new TextBox();
		clientTxtBox.getElement().setId("client_name");
		
		// Button buscar
		final Button searchButton = new Button("Buscar");
		searchButton.getElement().setId("searchButton");
				
				// Create a handler for the sendButton and nameField
				class MyHandler implements ClickHandler, KeyUpHandler {
							/**
							 * Fired when the user clicks on the sendButton.
							 */
							public void onClick(ClickEvent event) {
								final String clientName = clientTxtBox.getText();
								findCarSales(clientName);
							}

							/**
							 * Fired when the user types in the nameField.
							 */
							public void onKeyUp(KeyUpEvent event) {
								final String clientName = clientTxtBox.getText();
								
								if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {	
									findCarSales(clientName);			
								}
							}

							/**
							 * Send the name from the nameField to the server and wait for a response.
							 */
							private void findCarSales(String clientName) {
								carService.findCarSales(clientName, new AsyncCallback<SerialList<SaleInfo>>() {

									@Override
									public void onFailure(Throwable caught) {
										GWT.log("onFailure findCarSales...");	
									}

									@Override
									public void onSuccess(SerialList<SaleInfo> salesLst) {
										GWT.log("onSuccess findCarSales salesLst size: " + 
													salesLst.size());
										
										if (salesLst != null && salesLst.size() > 0) {
											resultsTable.clear();
											buildResultTable(salesLst);
										} else {
											Window.alert("Nao foi encontrado nenhuma venda de carro!");
										}
									}
								});	
							}
						}

				// Add a handler to send the name to the server
				MyHandler handler = new MyHandler();
				searchButton.addClickHandler(handler);
				
				// Create a table to layout the form options
				resultsTable = new FlexTable();
//				resultsTable.setCellSpacing(6);
				cellFormatter = resultsTable.getFlexCellFormatter();
				
				HorizontalPanel hpPanel = new HorizontalPanel();
				hpPanel.setSpacing(5);
				hpPanel.add(clientNameLb);
				hpPanel.add(clientTxtBox);
				
				VerticalPanel mainPanel = new VerticalPanel();
				mainPanel.add(hpPanel);
				mainPanel.add(searchButton);
				mainPanel.add(resultsTable);
							    		
			    // Associate the Main panel with the HTML host page.
			    RootPanel.get("screen").add(mainPanel);
	}
	
	public void buildResultTable(SerialList<SaleInfo> salesLst) {
		int rowNumber = 1;
		
		// Build Table Header
		buildTableHeader();
		
		for (SaleInfo sale : salesLst) {
			// Add some standard form options
		    resultsTable.setHTML(rowNumber, 0, sale.getSaleId() + "");
		    resultsTable.setHTML(rowNumber, 1, sale.getClientName());
		    resultsTable.setHTML(rowNumber, 2, sale.getBrand());
		    resultsTable.setHTML(rowNumber, 3, sale.getModel());
		    resultsTable.setHTML(rowNumber, 4, sale.getSaleValue());
		    
		    rowNumber++;
		}
	}
	
	private void buildTableHeader() {
		 // Add a title to the form
		resultsTable.setHTML(0, 0, "Sale Id");
	    cellFormatter.setHorizontalAlignment(
	        0, 0, HasHorizontalAlignment.ALIGN_CENTER);
	    
	    resultsTable.setHTML(0, 1, "Client Name");
	    cellFormatter.setHorizontalAlignment(
	        0, 1, HasHorizontalAlignment.ALIGN_CENTER);
	    
	    resultsTable.setHTML(0, 2, "Car Brand");
	    cellFormatter.setHorizontalAlignment(
	        0, 2, HasHorizontalAlignment.ALIGN_CENTER);
	    
	    resultsTable.setHTML(0, 3, "Car Model");
	    cellFormatter.setHorizontalAlignment(
	        0, 3, HasHorizontalAlignment.ALIGN_CENTER);
	   
	    resultsTable.setHTML(0, 4, "Sale Value");
	    cellFormatter.setHorizontalAlignment(
	        0, 4, HasHorizontalAlignment.ALIGN_CENTER);
	}
}
