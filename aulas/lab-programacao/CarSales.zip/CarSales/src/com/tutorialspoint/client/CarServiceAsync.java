package com.tutorialspoint.client;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.tutorialspoint.shared.SaleInfo;
import com.tutorialspoint.shared.SerialList;

/**
 * The async counterpart of <code>CarService</code>.
 */
public interface CarServiceAsync {	
	
	void findCarSales(String clientName, AsyncCallback<SerialList<SaleInfo>> asyncCallback);

}