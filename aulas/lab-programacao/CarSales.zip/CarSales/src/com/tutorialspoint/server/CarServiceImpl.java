package com.tutorialspoint.server;

import java.sql.Connection;
import java.sql.SQLException;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.tutorialspoint.client.CarService;
import com.tutorialspoint.shared.SaleInfo;
import com.tutorialspoint.shared.SerialList;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class CarServiceImpl extends RemoteServiceServlet implements CarService {
	
	public SerialList<SaleInfo> findCarSales(String clientName) {
		
		SerialList<SaleInfo> salesLst = null;
		try {
			Connection conn = DatabaseConnection.getDBConnection();
			salesLst = FindCarSalesInfoCommand.getCarSalesFromDatabase(conn, clientName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return salesLst;
	}	
}
