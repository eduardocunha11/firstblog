package com.tutorialspoint.server;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.tutorialspoint.shared.SaleInfo;
import com.tutorialspoint.shared.SerialList;

public class FindCarSalesInfoCommand {
	
	private static SerialList<SaleInfo> salesLst = new SerialList<SaleInfo>();
	
	public static SerialList<SaleInfo> getCarSalesFromDatabase(Connection conn, String client) {
		
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT s.sale_id, s.client_name, cb.brand, cm.model, s.sale_value ");
		builder.append("FROM sales s, car_brands cb, car_models cm ");
		builder.append("WHERE cb.brand_id = s.brand_id ");
		builder.append("AND cm.model_id = s.model_id ");
		
		if (client != null && !client.equals("")) {
		   builder.append("AND s.client_name LIKE '%" + client + "%'");
		}

		String sql = builder.toString();
		System.out.println("FindCarBrandsCommand SQL: " + sql);
		
		Statement stmt;
		ResultSet rs;
		Integer saleId;
		String clientName;
		String brand;
		String model;
		Double saleValue;
		
		SaleInfo saleInfo;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			if (rs != null) {
				while (rs.next()) {
					saleId = rs.getInt(1);
					clientName = rs.getString(2);
					brand = rs.getString(3);
					model = rs.getString(4);
					saleValue = rs.getDouble(5);
					
					saleInfo = new SaleInfo();
					saleInfo.setSaleId(saleId);
					saleInfo.setClientName(clientName);
					saleInfo.setModel(model);
					saleInfo.setBrand(brand);
					saleInfo.setSaleValue(saleValue + "");
					
					salesLst.add(saleInfo);	
				}
			} else {
				System.out.println("Nao foi possivel consultar a tabela sales!!!");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return salesLst;
	}
}
