package com.tutorialspoint.shared;

import java.io.Serializable;
import java.util.ArrayList;

public class SerialList<E> extends ArrayList<E> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
