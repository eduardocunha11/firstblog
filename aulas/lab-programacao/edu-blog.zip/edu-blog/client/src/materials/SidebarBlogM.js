import React from 'react'
import {Row, Col, Collection, CollectionItem} from 'react-materialize'

const SidebarBlogM = props => {
    return (
        <div className="sidebarblog-m">
        <Row>
            <Col m={6} s={12}>
                <Collection header="First Names">
                    <CollectionItem> Alvin </CollectionItem>
                    <CollectionItem> Alvin </CollectionItem>
                    <CollectionItem> Alvin </CollectionItem>
                    <CollectionItem> Alvin </CollectionItem>
                </Collection>
            </Col>
        </Row>
        </div>
    )
}

export default SidebarBlogM