import React from 'react'
import {Row, Col, Navbar, NavItem} from 'react-materialize'

const HeaderBlogM = props => {
    return (
        <div className="header-blog-m">
        <Row>
            <Col s={12}>
            <Navbar brand={<a />} alignLinks="right">
            <NavItem href=""> Getting started </NavItem>
            <NavItem href="components.html"> Components </NavItem>
            </Navbar>
            </Col>
        </Row>
        </div>
    )
}

export default HeaderBlogM




