import React, {Component} from 'react'
import {Row, Col, Card} from 'react-materialize'

const ContentBlogM = props => {
    return (
        <Row>
        <Col m={6} s={12}>
        <Card className="blue-grey darken-1"
              textClassName="white-text"
              title={props.posts.TITULO}
              actions={[<a />,<a />]}
        >
        <p>{props.posts.CONTEUDO}</p>
        <p>Autor: {props.posts.AUTOR}</p>
        </Card>
        </Col>
        </Row>
    )
}

export default ContentBlogM