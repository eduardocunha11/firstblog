
public class Horista extends Funcionario {

	private Double valorHora;
	private Integer qtdHorasTrabalhadas;
	
	public Horista(){}
	
	public Horista(Double valorHora, Integer qtdHorasTrabalhadas) {
		super();
		this.valorHora = valorHora;
		this.qtdHorasTrabalhadas = qtdHorasTrabalhadas;
	}

	public Double getValorHora() {
		return valorHora;
	}

	public void setValorHora(Double valorHora) {
		this.valorHora = valorHora;
	}

	public Integer getQtdHorasTrabalhadas() {
		return qtdHorasTrabalhadas;
	}

	public void setQtdHorasTrabalhadas(Integer qtdHorasTrabalhadas) {
		this.qtdHorasTrabalhadas = qtdHorasTrabalhadas;
	}

	@Override
	public Double getSalario() {
		return (valorHora * qtdHorasTrabalhadas);
	}
}
