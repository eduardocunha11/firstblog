
public class Comissionado extends Funcionario {

	private Double totalVendaMes;
	private Double percentualComissao;
	
	public Comissionado(){}
	
	public Comissionado(Double totalVendaMes, Double percentualComissao) {
		super();
		this.totalVendaMes = totalVendaMes;
		this.percentualComissao = percentualComissao;
	}

	public Double getTotalVendaMes() {
		return totalVendaMes;
	}

	public void setTotalVendaMes(Double totalVendaMes) {
		this.totalVendaMes = totalVendaMes;
	}

	public Double getPercentualComissao() {
		return percentualComissao;
	}

	public void setPercentualComissao(Double percentualComissao) {
		this.percentualComissao = percentualComissao;
	}

	@Override
	public Double getSalario() {
		return (totalVendaMes * percentualComissao);
	}
}
