import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Teste {
	
	private static Empresa empresa;
	private static List<Funcionario> funcionarios;
	private static Horista horista;
	private static Comissionado comissionado;
	
	public static void main(String[] args) {
	
		horista = new Horista();
		horista.setNome("Eduardo");
		horista.setQtdHorasTrabalhadas(360);
		horista.setValorHora(22.0);
		
		comissionado = new Comissionado();
		comissionado.setNome("Joao");
		comissionado.setTotalVendaMes(35000.0);
		comissionado.setPercentualComissao(0.25);
		
		empresa = new Empresa();
		empresa.setNome("Empresa ABC");
		empresa.setCnpj("354.342.014.976-89");
		
		
		funcionarios = new ArrayList<Funcionario>();
		funcionarios.add(horista);
		funcionarios.add(comissionado);
		
		empresa.setFuncionarios(funcionarios);
		

		Iterator<Funcionario> funcionariosIt = funcionarios.iterator();
		Funcionario funcionario = null;
		while (funcionariosIt.hasNext()) {
			funcionario = funcionariosIt.next();
			
			System.out.println("Nome: " + funcionario.getNome() + 
					" / Salario: " + funcionario.getSalario());
			
		}
	}
}
