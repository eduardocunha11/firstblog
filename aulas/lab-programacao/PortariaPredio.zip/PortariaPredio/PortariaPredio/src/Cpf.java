
public class Cpf extends DocumentoFederal {

	private String numero;
	
	public Cpf(){}
	
	public Cpf(String numero) {
		super();
		this.numero = numero;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	@Override
	public String getNumeroDocumento() {
		return numero;
	}
}
