
public class TituloEleitor extends DocumentoFederal {

	private String numero;
	private String zona;
	private String secao;
	
	public TituloEleitor(){}
		
	public TituloEleitor(String numero, String zona, String secao) {
		super();
		this.numero = numero;
		this.zona = zona;
		this.secao = secao;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getZona() {
		return zona;
	}

	public void setZona(String zona) {
		this.zona = zona;
	}

	public String getSecao() {
		return secao;
	}

	public void setSecao(String secao) {
		this.secao = secao;
	}

	@Override
	public String getNumeroDocumento() {
		return numero + "-" + zona + "-" + secao;
	}
}
