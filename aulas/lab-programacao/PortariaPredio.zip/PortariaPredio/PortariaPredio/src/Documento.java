
public abstract class Documento {
	
	public abstract String getNumeroDocumento();

}
