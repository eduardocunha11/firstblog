
public abstract class DocumentoEstadual extends Documento {

}
