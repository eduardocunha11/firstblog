import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Portaria {
	
	private static List<Pessoa> pessoas = new ArrayList<Pessoa>();
	
	public static void main(String[] args) {
		
		Cpf cpfP1 = new Cpf("092.400.266-22");
		
		Pessoa p1 = new Pessoa();
		p1.setNome("Eduardo");
		p1.setDocumento(cpfP1);
		
		Identidade idP2 = new Identidade("13.678.895", "GO");
		
		Pessoa p2 = new Pessoa();
		p2.setNome("Rogerio");
		p2.setDocumento(idP2);
		
		TituloEleitor tituloP3 = new TituloEleitor("12319865", "89", "335");
		Pessoa p3 = new Pessoa();
		p3.setNome("Marla");
		p3.setDocumento(tituloP3);
		
		// Adicionar os objetos na lista
		pessoas.add(p1);
		pessoas.add(p2);
		pessoas.add(p3);
		
		/*
		// Imprimir pessoas que passaram pela portaria
		Iterator<Pessoa> pessoasIt = pessoas.iterator();
		Pessoa pessoa = null;
		
		while (pessoasIt.hasNext()) {
			pessoa = pessoasIt.next();
			System.out.println(pessoa.getDocumentoInfo());
		}
		*/
		
		Pessoa pessoa = null;
		for (int i = 0; i < pessoas.size(); i++) {
			pessoa = pessoas.get(i);
			System.out.println(pessoa.getDocumentoInfo());
		}
	}
}
