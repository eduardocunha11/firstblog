
public abstract class DocumentoFederal extends Documento {

}
