
public class Identidade extends DocumentoEstadual {

	private String numero;
	private String estado;
	
	public Identidade(){}
	
	public Identidade(String numero, String estado) {
		super();
		this.numero = numero;
		this.estado = estado;
	}
	
	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public String getNumeroDocumento() {
		return numero + "-" + estado;
	}
}
