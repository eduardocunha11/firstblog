
import java.util.Scanner;
import java.util.Iterator;

public class Principal {
	
	public static void main(String args[]) {
		Contato c1, c2, c3;
		List<Contato> agenda = new ArrayList<Contato>();
		
		String nome1, nome2, nome3;
		String tel1, tel2, tel3;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Digite um nome: ");
		nome1 = in.next();
		
		System.out.println("Digite um telefone: ");
		tel1 = in.next();
		
		c1 = new Contato(nome1, tel1);
		
		System.out.println("Digite um nome: ");
		nome2 = in.next();
		
		System.out.println("Digite um telefone: ");
		tel2 = in.next();
		
		c2 = new Contato(nome2, tel2);
		
		System.out.println("Digite um nome: ");
		nome3 = in.next();
		
		System.out.println("Digite um telefone: ");
		tel3 = in.next();
		
		c3 = new Contato(nome3, tel3);
		
		// Adicionando objetos na lista de contatos
		agenda.add(c1);
		agenda.add(c2);
		agenda.add(c3);
		
		Iterator<Contato> it = agenda.iterator();
		Contato temp;
		while (it.hasNext()) {
			temp = it.next();
			System.out.println("Nome: " + temp.getNome() + 
			    " Telefone: " + temp.getTelefone());
		}
	}
}