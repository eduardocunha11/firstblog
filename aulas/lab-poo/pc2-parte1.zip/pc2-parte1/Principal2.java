import java.util.Scanner;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

public class Principal2 {
	
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);

		Contato[] contatos = new Contato[3];
		Contato temp = null;
		String nome = "";
		String telefone = "";
		
		for (int i = 0; i < contatos.length; i++) {
			System.out.println("Digite um nome: ");
			nome = in.next();
			
			System.out.println("Digite um telefone: ");
			telefone = in.next();
			
			temp = new Contato(nome, telefone);
			contatos[i] = temp;
		}
	}
}