
public class Aluno {
	
	private String nome;
	private String nroMatricula;
	
	// construtor padrão
	public Aluno(){}
	
	public Aluno(String nome, String nroMatricula) {		
		this.nome = nome;
		this.nroMatricula = nroMatricula;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getNroMatricula() {
		return nroMatricula;
	}
	
	public void setNroMatricula(String nroMatricula) {
		this.nroMatricula = nroMatricula;
	}
}