import java.util.Scanner;

public class Ex4 {
	
	private static int numero;
	
	public static void main(String[] args) {
	   //Cria um Scanner para entrada de dados a partir da
	   //janela de comando
	   Scanner in = new Scanner(System.in);
	   
	   numero = in.nextInt();
	   
	   if (numero % 2 == 0) {
		  // caso em que é par   
		  for (int i = numero; i > 0; i--) {
			  if (i % 2 == 0) {
				 System.out.println(i);  
			  }
		  }
	   } else {
		   System.out.println("Esse numero e impar!");
	   }
	}
}
